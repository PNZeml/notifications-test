namespace NotificationsTest.Utils {
    internal static class ApplicationConstants {
        public const string EntryForm = nameof(EntryForm);
    }
}