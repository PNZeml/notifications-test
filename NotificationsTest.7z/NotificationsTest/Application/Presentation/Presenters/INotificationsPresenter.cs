namespace NotificationsTest.Application.Presentation.Presenters {
    internal interface INotificationsPresenter { }
}